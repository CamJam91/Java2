/**
 * 
 */
/**
 * 
 */
module CaveDiver {
	requires java.desktop;
}