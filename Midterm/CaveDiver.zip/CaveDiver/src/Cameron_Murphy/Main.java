package Cameron_Murphy;
import javax.swing.JFrame;

public class Main {
	public static void main(String[] args) {
			//create CaveFrame
		JFrame frame = new CaveFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
