package edu.sinclair.cameron_murphy;

import javax.swing.JFrame;

public class HouseFrame extends JFrame {
	public HouseFrame() {
		add(new PictureComponent());
	}
}
