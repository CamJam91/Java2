/**
 * 
 */
/**
 * 
 */
module HouseMurphy {
	requires java.desktop;
}