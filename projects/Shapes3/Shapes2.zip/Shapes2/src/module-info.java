/**
 * 
 */
/**
 * 
 */
module Shapes2 {
	requires java.desktop;
}