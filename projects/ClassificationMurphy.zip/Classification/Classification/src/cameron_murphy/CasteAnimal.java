package cameron_murphy;
//Cameron Murphy CIS 2217 R01 9/25/2024
//interface for Caste Animal classes

public interface CasteAnimal {
	public void setCaste(String caste);
	public String getCaste();
}
