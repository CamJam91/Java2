package cameron_murphy;
//Cameron Murphy CIS 2217 R01 9/25/2024
//interface for Anteater classes

public interface AntEater {
	public void eatAnt();
	public int getAntsEaten();
}
