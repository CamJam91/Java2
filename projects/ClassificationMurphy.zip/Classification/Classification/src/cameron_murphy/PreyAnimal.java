package cameron_murphy;
//Cameron Murphy CIS 2217 R01 9/25/2024
//interface for prey animals
public interface PreyAnimal {
	public void setEaten(Boolean eaten);
	public Boolean getEaten();
}
