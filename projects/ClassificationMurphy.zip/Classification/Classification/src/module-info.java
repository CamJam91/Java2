/**
 * 
 */
/**
 * 
 */
module Classification {
	requires org.junit.jupiter.api;
}